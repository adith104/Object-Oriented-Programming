How to run:
1)Run the server
2)Run as many clients as needed.
3)First connect all the clients to the server 
4)The send messages between client using the text area.