public class ShapeException extends Exception{
	
	public ShapeException(String emsg)
	{
		super(emsg);
	}

}
